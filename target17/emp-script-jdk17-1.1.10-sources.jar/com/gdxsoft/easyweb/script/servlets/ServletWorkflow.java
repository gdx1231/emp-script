/**
 * 
 */
package com.gdxsoft.easyweb.script.servlets;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.gdxsoft.easyweb.define.UpdateWorkflow;
import com.gdxsoft.easyweb.script.RequestValue;
import com.gdxsoft.easyweb.script.Workflow.EwaWfMain;
import com.gdxsoft.easyweb.script.display.frame.FrameParameters;
import com.gdxsoft.easyweb.utils.UJSon;
import com.gdxsoft.easyweb.utils.Utils;
import com.gdxsoft.easyweb.utils.msnet.MStr;

/**
 * @author Administrator
 * 
 */
public class ServletWorkflow extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8377846637723766982L;

	/**
	 * 
	 */

	public ServletWorkflow() {
		super();
	}

	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request  the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException      if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.show(request, response);
	}

	private void show(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		RequestValue rv = new RequestValue(request, request.getSession());
		UpdateWorkflow u = new UpdateWorkflow();
		String s = "";
		String wfType = rv.getString(FrameParameters.EWA_WF_TYPE);
		if (wfType == null) {
			wfType = "";
		}
		wfType = wfType.trim().toLowerCase();

		String contentType = FileOut.MAP.get("json");
		JSONObject obj = new JSONObject();

		if (wfType.equals("cnns")) {
			s = u.updateCnns(rv);
		} else if (wfType.equals("units")) {
			s = u.updateUnits(rv);
		} else if (wfType.equals("gunid")) {
			int num = 20;
			try {
				num = rv.getInt("num");
			} catch (Exception e1) {

			}
			if (num <= 0) {
				num = 20;
			}
			MStr s1 = new MStr();
			s1.a("[");
			for (int i = 0; i < num; i++) {
				if (i > 0) {
					s1.a(",");
				}
				s1.al("'" + Utils.getGuid() + "'");
			}
			s1.a("]");
			s = s1.toString();
		} else if (wfType.equals("all")) {
			s = u.updateUnits(rv);
			s = u.updateCnns(rv);
		} else if (wfType.equals("get")) {
			s = u.getUnitsCnns(rv);
		} else if (wfType.equals("ins_post")) { // 用户提交
			EwaWfMain main = new EwaWfMain();
			try {
				String wfId = rv.getString("WF_ID");
				main.initDlv(wfId, rv);
				main.doPost();
				obj.put("RST", true);
				s = obj.toString();
			} catch (Exception e) {
				s = UJSon.rstFalse(e.getLocalizedMessage()).toString();
			}
		} else if (wfType.equals("ins_get")) { // 用户提交
			EwaWfMain main = new EwaWfMain();

			try {
				String wfId = rv.getString("WF_ID");
				main.initDlv(wfId, rv);
				s = main.doGetStatusDlv(rv);
				contentType = FileOut.MAP.get("js");

			} catch (Exception e) {
				s = UJSon.rstFalse(e.getLocalizedMessage()).toString();

			}
		} else {
			 s = UJSon.rstFalse("Invalid workflow type").toString();
		}
		response.setCharacterEncoding("UTF-8");
		response.setContentType(contentType);
		GZipOut out = new GZipOut(request, response);
		out.outContent(s);

	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request  the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException      if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.show(request, response);
	}

	/**
	 * Returns information about the servlet, such as author, version, and
	 * copyright.
	 * 
	 * @return String information about this servlet
	 */
	public String getServletInfo() {
		return "EWA(v2.0)";
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
